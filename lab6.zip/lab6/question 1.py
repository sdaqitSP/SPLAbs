li=range(2000,3200)

for n in li:
	if ((n%7) and (n%5 !=0)):
		print (n),", ",