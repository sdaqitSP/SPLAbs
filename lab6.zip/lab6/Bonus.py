import calendar
y=int(input("enter year"))
m=int(input("enter month"))
print(calandar.month(y,m))

'''import calendar
x=calandar.month(2018,4)
print(x)'''