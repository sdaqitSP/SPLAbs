#!/bin/bash

oldIFS=$IFS
IFS=`\n`
arr=(`cat ./q1.sh`)
 
