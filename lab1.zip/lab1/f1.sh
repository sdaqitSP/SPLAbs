#!/bin/bash

echo $PWD
echo $pwd
echo "$PWD"
