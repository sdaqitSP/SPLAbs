

int isEqual(int a, int b);

void swap(int* a, int* b);
